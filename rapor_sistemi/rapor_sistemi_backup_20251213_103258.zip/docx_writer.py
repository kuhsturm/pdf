"""
DOCX Yazıcı Modülü v2
Şablon DOCX dosyasını verilerle doldurur.
Güncellemeler:
- Ana Dağıtım Pano bilgileri desteği
- Tüm kontrol kriterleri doldurma
- Calibri 6pt font (Linye Adı sütunu)
- Otomatik kusur açıklaması
- Iz otomatik hesaplama
"""

from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from typing import Dict, List, Any, Optional
import os


class DocxWriter:
    """DOCX şablon dosyasını verilerle doldurur."""
    
    def __init__(self, template_path: str):
        """
        Args:
            template_path: Şablon DOCX dosyasının yolu
        """
        self.template_path = template_path
        self.doc = None
        
    def load_template(self) -> bool:
        """Şablon dosyasını yükler."""
        if not os.path.exists(self.template_path):
            raise FileNotFoundError(f"Sablon bulunamadi: {self.template_path}")
        
        self.doc = Document(self.template_path)
        return True
    
    def _get_cell_safe(self, table, row_idx: int, col_idx: int):
        """Güvenli hücre erişimi."""
        try:
            if row_idx < len(table.rows) and col_idx < len(table.rows[row_idx].cells):
                return table.rows[row_idx].cells[col_idx]
        except (IndexError, AttributeError):
            pass
        return None
    
    def _replace_placeholder_in_cell(self, cell, placeholder: str, value: str, font_size: int = 9):
        """Hücredeki placeholder'ı değerle değiştirir, font boyutu 9pt."""
        if cell is None or not placeholder or value is None:
            return
        
        for para in cell.paragraphs:
            for run in para.runs:
                if placeholder in run.text:
                    run.text = run.text.replace(placeholder, str(value))
                    # Font boyutunu 9pt yap
                    run.font.size = Pt(font_size)
    
    def _set_cell_value(self, cell, value: str, font_name: str = None, font_size: int = 9):
        """Hücre değerini ayarlar, mevcut içeriği TAMAMEN temizler. Varsayılan font 9pt."""
        if cell is None or value is None:
            return
        
        # TÜM paragrafları temizle (birden fazla paragraf olabilir)
        for para in cell.paragraphs:
            for run in para.runs:
                run.text = ""
            # Paragrafın kendi text'ini de temizle
            if hasattr(para, '_p'):
                for child in list(para._p):
                    if child.tag.endswith('}r') or child.tag.endswith('}bookmarkStart') or child.tag.endswith('}bookmarkEnd'):
                        continue
        
        # İlk paragrafa yeni değeri yaz
        if cell.paragraphs:
            para = cell.paragraphs[0]
            # Tüm run'ları temizle
            for run in para.runs:
                run.text = ""
            
            # İlk run'a yaz veya yeni run ekle
            if para.runs:
                run = para.runs[0]
                run.text = str(value)
            else:
                run = para.add_run(str(value))
            
            # Font ayarları - varsayılan 9pt
            if font_name:
                run.font.name = font_name
            run.font.size = Pt(font_size)  # Her zaman font boyutu uygula
        else:
            cell.text = str(value)
    
    def fill_firma_bilgileri(self, data: Dict[str, Any]):
        """Firma bilgilerini doldurur (Tablo 1)."""
        if not self.doc or not self.doc.tables:
            return
        
        table = self.doc.tables[0]  # İlk tablo
        
        # Alan eşlemesi - Excel'den gelen alan adları
        field_mapping = {
            'Firma Adi': (1, 2),
            'Rapor Numarasi': (1, 11),
            'Adres': (2, 2),
            'Rapor Tarihi': (2, 11),
            'ISG Katip ID': (3, 11),
            'Kontrol Baslangic': (4, 11),
            'Kontrol Bitis': (5, 11),
            'SGK Sicil': (6, 2),
            'Sonraki Kontrol': (6, 11),
        }
        
        for field_name, (row, col) in field_mapping.items():
            if field_name in data:
                cell = self._get_cell_safe(table, row, col)
                self._set_cell_value(cell, data[field_name])
    
    def fill_ana_dagitim_pano(self, data: Dict[str, Any], pano_adi: str = None):
        """Ana Dağıtım Pano bilgilerini doldurur (Tablo 1 - 2.1 DETAY BİLGİLER).
        
        Satır indeksleri (0-indexed):
        - Satır 10: Enerji sağlayan kuruluş (sütun 1), Şebeke tipi (sütun 7 - checkbox)
        - Satır 13: Ekipman kullanım amacı (sütun 7), Son kontrol tarihi (sütun 12)
        - Satır 14-17: Faz iletkenleri, Topraklama direnci, İletken kesitleri
        - Satır 18: RCD bilgisi (sütun 12)
        - Satır 19: RCD test bilgisi (sütun 12)
        """
        if not self.doc or not self.doc.tables:
            return
        
        table = self.doc.tables[0]
        
        # Pano adı (Ekipman Kullanım Amacı - Satır 13, Sütun 7)
        if pano_adi:
            cell = self._get_cell_safe(table, 13, 7)
            self._set_cell_value(cell, pano_adi)
        
        # Metin alanları doldurulur
        field_mapping = {
            # Satır 10 - Enerji sağlayan kuruluş
            'Enerji Saglayan Kurulus': (10, 1),
            
            # Satır 14 - Temel topraklama direnci (sütun 9'da [BOS] alanı)
            'Temel Topraklama Direnci (Ohm)': (14, 9),
            
            # Satır 15 - İlave topraklama elektrotu 
            'Ilave Topraklama Elektrotu Detaylari': (15, 9),
            
            # Satır 16 - Sistem topraklama iletkeni kesiti
            'Sistem Topraklama Iletkeni Kesiti (mm2)': (16, 9),
            
            # Satır 17 - Ana eşpotansiyel iletkeni kesiti
            'Ana Espotansiyel Iletkeni Kesiti (mm2)': (17, 9),
            
            # Satır 18 - RCD bilgisi (placeholder tabanlı)
            'Ana RCD Tipi': (18, 12),
            
            # Satır 19 - RCD test bilgisi (sütun 12)
            'Ana RCD Test Akimi (mA)': (19, 12),
        }
        
        for field_name, (row, col) in field_mapping.items():
            if field_name in data:
                cell = self._get_cell_safe(table, row, col)
                value = data[field_name]
                
                # RCD alanları için birleştirme
                if field_name == 'Ana RCD Tipi':
                    rcd_tipi = data.get('Ana RCD Tipi', '')
                    rcd_dayanim = data.get('Ana RCD Dayanim Akimi (mA)', '')
                    if rcd_tipi and rcd_dayanim:
                        value = f"{rcd_tipi} {rcd_dayanim} mA"
                    elif rcd_dayanim:
                        value = f"{rcd_dayanim} mA"
                
                elif field_name == 'Ana RCD Test Akimi (mA)':
                    test_akim = data.get('Ana RCD Test Akimi (mA)', '')
                    acma_suresi = data.get('Ana RCD Acma Suresi (ms)', '')
                    if test_akim and acma_suresi:
                        value = f"{test_akim} mA / {acma_suresi} ms"
                    elif test_akim:
                        value = f"{test_akim} mA"
                
                self._set_cell_value(cell, value)
        
        # === PLACEHOLDER TABANLI DEĞİŞTİRME ===
        # Tablo 1'deki tüm placeholder'ları Excel verisiyle değiştir
        
        # Z_E'den I_f otomatik hesapla: I_f = 230 / Z_E
        z_e_value = data.get('Dis Cevrim Empedansi Z_E (Ohm)', '')
        i_f_value = ''
        if z_e_value:
            try:
                z_e_float = float(str(z_e_value).replace(',', '.'))
                if z_e_float > 0:
                    i_f_calculated = 230 / z_e_float  # Ampere
                    if i_f_calculated >= 1000:
                        i_f_value = f"{i_f_calculated/1000:.2f}"  # kA olarak
                    else:
                        i_f_value = f"{i_f_calculated:.1f}"  # A olarak
            except (ValueError, ZeroDivisionError):
                pass
        
        placeholder_mapping = {
            'ADP_tip': data.get('Ana Kesici Tipi', ''),  # Ana Kesici Tipi
            'ADP_anma': data.get('Ana Kesici Nominal Akimi', ''),  # Ana Kesici Nominal Akım
            'RCD_tipi': data.get('Ana RCD Tipi', ''),  # RCD Tipi
            'RCD_dayanim': data.get('Ana RCD Dayanim Akimi (mA)', ''),  # RCD Dayanım
            'Z_E': str(z_e_value) if z_e_value else '',  # Dış çevrim empedansı
            'I_f': i_f_value,  # Hata akımı (otomatik hesaplanan)
        }
        
        # Tablo 1'deki tüm hücrelerde placeholder'ları değiştir
        for row in table.rows:
            for cell in row.cells:
                for placeholder, value in placeholder_mapping.items():
                    if value:  # Sadece boş olmayan değerleri yaz
                        self._replace_placeholder_in_cell(cell, placeholder, str(value))
    
    def fill_cihaz_bilgileri(self, data: Dict[str, Any]):
        """Cihaz bilgilerini doldurur (Tablo 1 - 3. ve 4. bölümler)."""
        if not self.doc or not self.doc.tables:
            return
        
        table = self.doc.tables[0]
        
        # Termal Kamera
        if 'termal_kamera' in data:
            tk = data['termal_kamera']
            mapping = {
                'Cihaz Adi': (26, 3),
                'Kalibrasyon Tarihi': (27, 3),
                'Gecerlilik Tarihi': (28, 3),
                'Seri No': (29, 3),
                'Kalibrasyon No': (30, 3),
            }
            for field, (row, col) in mapping.items():
                if field in tk:
                    cell = self._get_cell_safe(table, row, col)
                    self._set_cell_value(cell, tk[field])
        
        # Ölçüm Aleti
        if 'olcum_aleti' in data:
            oa = data['olcum_aleti']
            mapping = {
                'Cihaz Adi': (32, 3),
                'Kalibrasyon Tarihi': (33, 3),
                'Gecerlilik Tarihi': (34, 3),
                'Seri No': (35, 3),
                'Kalibrasyon No': (36, 3),
            }
            for field, (row, col) in mapping.items():
                if field in oa:
                    cell = self._get_cell_safe(table, row, col)
                    self._set_cell_value(cell, oa[field])
    
    def fill_gozle_kontrol(self, data: Dict[str, Any]):
        """Gözle kontrol bölümünü doldurur (Tablo 2 - TÜM MADDELER)."""
        if not self.doc or len(self.doc.tables) < 2:
            return
        
        table = self.doc.tables[1]  # 2. tablo
        
        # Pano adı
        if 'pano_adi' in data:
            cell = self._get_cell_safe(table, 2, 1)
            self._set_cell_value(cell, data['pano_adi'])
        
        # Kontroller - Excel'deki her satırı rapordaki karşılığına eşle
        if 'kontroller' in data:
            kontroller = data['kontroller']
            
            # Detaylı eşleme - Excel alan adı: (tablo satırı, sütun)
            kontrol_mapping = {
                'Kablo Sebeke Tarafi': (5, 1),
                'Kablo Donanim Tarafi': (5, 3),
                'Pano Sabitlenmesi (Depreme Dayaniklilik)': (6, 1),
                'Dis Darbelere Karsi Koruma Onlemi': (6, 3),
                'Elektrik Panosu Etrafinda Yabanci Malzemeler': (7, 1),
                'Zemin Izolasyonu': (7, 3),
                'Topraklama Iletkeni': (9, 1),
                'Ana Potansiyel Dengeleme Iletkeni': (9, 3),
                'Ek Potansiyel Dengeleme Iletkeni (Tamamlayici)': (10, 1),
                'Ek Potansiyel Dengeleme Iletkeni': (10, 1),  # Alternatif isim
                'Pano Kapak Baglantisi Kontrolu 6 mm2': (10, 3),
                'Elektriksel Olmayan Tesislere Yaklasma ve Diger Etkilerin Kontrolu': (12, 1),
                'Bant I ve Bant II Ayrilmasi, Bant II Yalitimi': (12, 3),
                'Bant Ayrilmasi': (12, 3),  # Kısa isim
                'Guvenlik Devre Ayrilmasi': (13, 1),
                'Pano Ic Kapak, Faza Erisim Engeli veya Pleksi Koruma': (13, 3),
                'Pano Ic Kapak': (13, 3),  # Kısa isim
                'Semalar, Talimatlar, Devre Cizimleri ve Kisa Bilgiler': (15, 1),
                'Koruma Cihaz ve Terminal Etiket': (15, 3),
                'Tehlike Isaretleri ve Diger Uyari Isaretleri': (16, 1),
                'Tehlike Isaretleri': (16, 1),  # Kısa isim
                'Kablo Yollarinin Uygunlugu ve Mekanik Koruma': (18, 1),
                'Kablo Yollari': (18, 1),  # Kısa isim
                'Kablo Renk Kodlari (Notr: Mavi, Toprak: Sari/Yesil)': (18, 3),
                'Kablo Renk Kodlari': (18, 3),  # Kısa isim
                'Tesisat Yontemi': (19, 1),
                'Yangin Engeli, Uygun Kilitleme ve Sicaklik Etkisine Karsi Koruma': (19, 3),
                'Yangin Engeli': (19, 3),  # Kısa isim
                'Fotograf Tarihi': (21, 1),
                'Fotograf No': (22, 1),
                'Kontak Gevsekligi Isinmasi': (21, 3),
                'Asiri Yuk Isinmasi (PVC Kablolar Icin >70 derece)': (22, 3),
                'Asiri Yuk Isinmasi': (22, 3),  # Kısa isim
                'Ekipman Yakininda Elektriksel Ekipman Yangin Sondurme Tertibati': (24, 1),
                'Yangin Sondurme': (24, 1),  # Kısa isim
                'Ekipman Temizlik/Bakim Durumu': (24, 3),
                'Ekipman Temizlik': (24, 3),  # Kısa isim
                'Pano Ici ve Baglantilarinin Korozyon Kontrolu': (25, 1),
                'Korozyon Kontrolu': (25, 1),  # Kısa isim
                'Ekipman Ici veya Yakininda Acil Durum Aydinlatma Tertibati': (25, 3),
                'Acil Durum Aydinlatma': (25, 3),  # Kısa isim
            }
            
            for field, (row, col) in kontrol_mapping.items():
                if field in kontroller:
                    cell = self._get_cell_safe(table, row, col)
                    self._set_cell_value(cell, kontroller[field])
        
        # === GK_XX PLACEHOLDER DEĞİŞTİRME ===
        # Gözle Kontrol tablosundaki GK_01 - GK_29 placeholder'larını değiştir
        if 'kontroller' in data:
            kontroller = data['kontroller']
            
            # GUI alan adı -> GK_XX placeholder eşleme (TAM 29 ALAN)
            gk_placeholder_mapping = {
                'Kablo Sebeke Tarafi': 'GK_01',
                'Pano Sabitlenmesi': 'GK_02',
                'Elektrik Panosu Etrafinda Yabanci Malzemeler': 'GK_03',
                'Kablo Donanim Tarafi': 'GK_04',
                'Dis Darbelere Karsi Koruma Onlemi': 'GK_05',
                'Zemin Izolasyonu': 'GK_06',
                'Topraklama Iletkeni': 'GK_07',
                'Ek Potansiyel Dengeleme Iletkeni': 'GK_08',
                'Ana Potansiyel Dengeleme Iletkeni': 'GK_09',
                'Pano Kapak Baglantisi Kontrolu 6 mm2': 'GK_10',
                'Elektriksel Olmayan Tesislere Yaklasma': 'GK_11',
                'Guvenlik Devre Ayrilmasi': 'GK_12',
                'Bant Ayrilmasi': 'GK_13',
                'Pano Ic Kapak': 'GK_14',
                'Semalar Talimatlar': 'GK_15',
                'Tehlike Isaretleri': 'GK_16',
                'Koruma Cihaz ve Terminal Etiket': 'GK_17',
                'Kablo Yollari': 'GK_18',
                'Tesisat Yontemi': 'GK_19',
                'Kablo Renk Kodlari': 'GK_20',
                'Yangin Engeli': 'GK_21',
                'Kontak Gevsekligi Isinmasi': 'GK_22',
                'Asiri Yuk Isinmasi': 'GK_23',
                'Fotograf Tarihi': 'GK_24',
                'Fotograf No': 'GK_25',
                'Yangin Sondurme': 'GK_26',
                'Korozyon Kontrolu': 'GK_27',
                'Ekipman Temizlik': 'GK_28',
                'Acil Durum Aydinlatma': 'GK_29',
            }
            
            # Tablo 2'deki tüm hücrelerde GK_XX placeholder'ları değiştir
            for row in table.rows:
                for cell in row.cells:
                    for field_name, placeholder in gk_placeholder_mapping.items():
                        if field_name in kontroller:
                            value = kontroller[field_name]
                            if value:
                                self._replace_placeholder_in_cell(cell, placeholder, str(value))
    
    def fill_fonksiyon_testleri(self, data: List[Dict[str, Any]], ana_pano_data: Dict[str, Any] = None):
        """Fonksiyon testleri bölümünü doldurur (Tablo 3).
        
        ana_pano_data: AnaDagitimPano verisi - placeholder değerleri için kullanılır
        """
        if not self.doc or len(self.doc.tables) < 3:
            return
        
        table = self.doc.tables[2]  # 3. tablo
        
        # === PLACEHOLDER DEĞİŞTİRME (Tablo 3) ===
        if ana_pano_data:
            # Z_ln'den 380/Z_ln otomatik hesapla
            z_ln_value = ana_pano_data.get('Faz-Notr Cevrim Empedansi Z_ln (Ohm)', '')
            kisa_devre = ''
            if z_ln_value:
                try:
                    z_ln_float = float(str(z_ln_value).replace(',', '.'))
                    if z_ln_float > 0:
                        kd = 380 / z_ln_float / 1000  # kA olarak
                        kisa_devre = f"{kd:.2f}"
                except (ValueError, ZeroDivisionError):
                    pass
            
            placeholder_mapping = {
                'PANO_adi1': ana_pano_data.get('Pano Adi (PANO_adi1)', ''),
                'Z_x': ana_pano_data.get('Faz-Toprak Cevrim Empedansi Z_x (Ohm)', ''),
                'Z_ln': z_ln_value,
                '380/Z_ln': kisa_devre,
                'F_F': ana_pano_data.get('Gerilim F-F (V)', ''),
                'L_N': ana_pano_data.get('Gerilim L-N (V)', ''),
                'N_PE': ana_pano_data.get('Gerilim N-PE (V)', ''),
                'PARAFUDR_TIP': ana_pano_data.get('Parafudr Tipi', ''),
                'PARAFUDR_Imax': ana_pano_data.get('Parafudr Imax (kA)', ''),
            }
            
            # Tablo 3'teki tüm hücrelerde placeholder'ları değiştir
            for row in table.rows:
                for cell in row.cells:
                    for placeholder, value in placeholder_mapping.items():
                        if value:
                            self._replace_placeholder_in_cell(cell, placeholder, str(value))
        
        # Veri satırları 10'dan başlıyor (0-indexed)
        start_row = 10
        existing_rows = len(table.rows)
        
        # Sütun eşlemesi - Excel'den gelen başlıklar
        col_mapping = {
            'Linye Adi': 1,
            'Acma Egrisi': 3,
            'Kutup Sayisi': 4,
            'In (A)': 5,
            'Icu (kA)': 7,
            'Faz Kesiti (mm2)': 9,
            'N Kesiti (mm2)': 11,
            'PE Kesiti (mm2)': 12,
            'Ib (A)': 14,
            'Iz (A)': 16,  # Otomatik hesaplanmış
            'RCD mA': 17,
            'RCD ms': 19,
            'Sonuc': 21,
        }
        
        for i, row_data in enumerate(data):
            row_idx = start_row + i
            
            # Eğer yeterli satır yoksa, yeni satır ekle
            while row_idx >= len(table.rows):
                # Son satırı kopyala (format için)
                new_row = table.add_row()
                # Satır numarasını yaz
                cell = new_row.cells[0]
                cell.text = str(row_idx - start_row + 1)
            
            for field, col in col_mapping.items():
                if field in row_data and row_data[field]:
                    cell = self._get_cell_safe(table, row_idx, col)
                    # Tüm alanlar için 6pt font
                    self._set_cell_value(cell, row_data[field], font_size=6)
    
    def add_thermal_images(self, image_paths: List[str]):
        """Ekipman Fotoğrafları bölümüne termal görüntüleri ekler (Tablo 5)."""
        if not self.doc or len(self.doc.tables) < 5:
            return
        
        table = self.doc.tables[4]  # 5. tablo (Fotoğraflar)
        
        # Fotoğraf hücresi (satır 1)
        if len(table.rows) > 1 and image_paths:
            cell = table.rows[1].cells[0]
            
            # Hücreyi temizle
            for para in cell.paragraphs:
                for run in para.runs:
                    run.text = ""
            
            # Görüntüleri ekle (son 2 görsel)
            para = cell.paragraphs[0] if cell.paragraphs else cell.add_paragraph()
            
            for img_path in image_paths:  # Zaten son 2 görsel gelecek
                if os.path.exists(img_path):
                    run = para.add_run()
                    run.add_picture(img_path, width=Inches(2.0))
                    run.add_text("  ")  # Görüntüler arası boşluk
    
    def generate_kusur_aciklamasi(self, kusurlar: List[Dict[str, str]]) -> str:
        """Kusur listesinden açıklama metni oluşturur."""
        if not kusurlar:
            return ""
        
        kusur_texts = []
        for kusur in kusurlar:
            derece = kusur.get('derece', '*')
            madde = kusur.get('madde', '')
            kusur_texts.append(f"{derece} {madde}")
        
        return "\n".join(kusur_texts)
    
    def fill_sonuc(self, data: Dict[str, Any], kusurlar: List[Dict[str, str]] = None):
        """Sonuç ve kanaat bölümünü doldurur."""
        if not self.doc or len(self.doc.tables) < 4:
            return
        
        # Tablo 4 - Kusur Açıklamaları (OTOMATIK)
        if len(self.doc.tables) >= 4:
            table = self.doc.tables[3]
            if len(table.rows) > 1:
                cell = self._get_cell_safe(table, 1, 0)
                
                # Kusur açıklamasını oluştur
                if kusurlar:
                    kusur_metni = self.generate_kusur_aciklamasi(kusurlar)
                    self._set_cell_value(cell, kusur_metni)
                else:
                    self._set_cell_value(cell, "Herhangi bir kusur tespit edilmemiştir.")
        
        # Tablo 5 - Ek Notlar
        if 'Ek Notlar' in data and len(self.doc.tables) >= 5:
            # Notlar bölümü için tablo 5'in ilgili hücresine yaz
            pass
    
    def save(self, output_path: str):
        """Belgeyi kaydeder."""
        if not self.doc:
            raise ValueError("Belge yuklu degil")
        
        # Çıktı klasörünü oluştur
        output_dir = os.path.dirname(output_path)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)
        
        self.doc.save(output_path)
        return output_path


# Test için
if __name__ == "__main__":
    template_path = r"c:\Users\cmshe\OneDrive\Masaüstü\BUILDV\Elektrik Tesisatı Gözle Kontrol ve Fonksyion Testleri Periyodik Kontrol Raporu.docx"
    
    writer = DocxWriter(template_path)
    writer.load_template()
    
    # Test verisi
    test_data = {
        'Firma Adi': 'TEST FIRMA A.S.',
        'Rapor Numarasi': '2025-001',
        'Rapor Tarihi': '12.12.2025',
    }
    
    writer.fill_firma_bilgileri(test_data)
    
    output_path = r"c:\Users\cmshe\OneDrive\Masaüstü\BUILDV\rapor_sistemi\test_output.docx"
    writer.save(output_path)
    print(f"Test raporu olusturuldu: {output_path}")
