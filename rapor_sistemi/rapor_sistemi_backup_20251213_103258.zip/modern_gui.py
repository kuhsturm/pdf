"""
Elektrik Rapor Sistemi - Modern GUI
CustomTkinter tabanlı tümleşik veri girişi ve rapor oluşturma arayüzü.
"""

import customtkinter as ctk
from tkinter import messagebox, filedialog
import tkinter as tk
from typing import Dict, Any, List, Optional
import os
import json
from datetime import datetime

# Tema ayarları
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")


class ScrollableFrame(ctk.CTkScrollableFrame):
    """Kaydırılabilir frame."""
    pass


class DragDropFrame(ctk.CTkFrame):
    """Sürükle-bırak dosya yükleme alanı."""
    
    def __init__(self, master, file_types: List[str] = None, on_drop=None, **kwargs):
        super().__init__(master, **kwargs)
        self.file_types = file_types or ['.docx', '.xlsx']
        self.on_drop = on_drop
        self.dropped_files = []
        
        self.configure(fg_color="#2b2b2b", border_width=2, border_color="#565656")
        
        # İkon ve metin
        self.label = ctk.CTkLabel(
            self, 
            text="📁 Dosyaları buraya sürükleyin\nveya tıklayarak seçin",
            font=ctk.CTkFont(size=14),
            text_color="#888888"
        )
        self.label.pack(expand=True, fill="both", padx=20, pady=40)
        
        # Dosya listesi
        self.files_label = ctk.CTkLabel(self, text="", font=ctk.CTkFont(size=11))
        self.files_label.pack(pady=(0, 10))
        
        # Tıklama ile dosya seçme
        self.bind("<Button-1>", self.browse_files)
        self.label.bind("<Button-1>", self.browse_files)
        
        # Sürükle-bırak desteği (tkinterdnd2 gerektiriyor)
        try:
            self.drop_target_register('DND_Files')
            self.dnd_bind('<<Drop>>', self.handle_drop)
        except:
            pass  # DnD yoksa normal devam et
    
    def browse_files(self, event=None):
        """Dosya seçme dialogu."""
        filetypes = [("Desteklenen dosyalar", " ".join(f"*{ext}" for ext in self.file_types))]
        files = filedialog.askopenfilenames(filetypes=filetypes)
        if files:
            self.add_files(list(files))
    
    def handle_drop(self, event):
        """Sürükle-bırak işlemi."""
        files = self.tk.splitlist(event.data)
        valid_files = [f for f in files if any(f.lower().endswith(ext) for ext in self.file_types)]
        if valid_files:
            self.add_files(valid_files)
    
    def add_files(self, files: List[str]):
        """Dosyaları listeye ekle."""
        self.dropped_files.extend(files)
        self.update_display()
        if self.on_drop:
            self.on_drop(files)
    
    def update_display(self):
        """Dosya listesini güncelle."""
        if self.dropped_files:
            names = [os.path.basename(f) for f in self.dropped_files[-3:]]  # Son 3
            text = "\n".join(f"✓ {n}" for n in names)
            if len(self.dropped_files) > 3:
                text += f"\n... ve {len(self.dropped_files) - 3} dosya daha"
            self.files_label.configure(text=text, text_color="#4CAF50")
            self.label.configure(text="📁 Daha fazla dosya eklemek için\ntıklayın veya sürükleyin")
    
    def clear(self):
        """Dosya listesini temizle."""
        self.dropped_files = []
        self.files_label.configure(text="")
        self.label.configure(text="📁 Dosyaları buraya sürükleyin\nveya tıklayarak seçin")


class DataEntryTab(ctk.CTkFrame):
    """Veri girişi sekmesi için temel sınıf."""
    
    def __init__(self, master, fields: List[tuple], **kwargs):
        super().__init__(master, **kwargs)
        self.fields = fields
        self.entries = {}
        self.create_widgets()
    
    def create_widgets(self):
        """Form alanlarını oluştur."""
        scroll = ScrollableFrame(self, label_text="")
        scroll.pack(fill="both", expand=True, padx=10, pady=10)
        
        for i, (field_name, field_type, options) in enumerate(self.fields):
            row_frame = ctk.CTkFrame(scroll, fg_color="transparent")
            row_frame.pack(fill="x", pady=5, padx=5)
            
            # Etiket
            label = ctk.CTkLabel(row_frame, text=field_name, width=250, anchor="w")
            label.pack(side="left", padx=(0, 10))
            
            # Giriş alanı türüne göre widget
            if field_type == "text":
                entry = ctk.CTkEntry(row_frame, width=300)
                entry.pack(side="left", fill="x", expand=True)
                if options:
                    entry.insert(0, options)
            
            elif field_type == "dropdown":
                entry = ctk.CTkComboBox(row_frame, values=options, width=300)
                entry.pack(side="left")
                if options:
                    entry.set(options[0])
            
            elif field_type == "date":
                entry = ctk.CTkEntry(row_frame, width=150, placeholder_text="GG.AA.YYYY")
                entry.pack(side="left")
                if options:
                    entry.insert(0, options)
            
            elif field_type == "number":
                entry = ctk.CTkEntry(row_frame, width=150)
                entry.pack(side="left")
                if options:
                    entry.insert(0, str(options))
            
            else:
                entry = ctk.CTkEntry(row_frame, width=300)
                entry.pack(side="left", fill="x", expand=True)
            
            self.entries[field_name] = entry
    
    def get_data(self) -> Dict[str, Any]:
        """Form verilerini al."""
        data = {}
        for field_name, entry in self.entries.items():
            if isinstance(entry, ctk.CTkComboBox):
                data[field_name] = entry.get()
            else:
                data[field_name] = entry.get()
        return data
    
    def set_data(self, data: Dict[str, Any]):
        """Form verilerini ayarla."""
        for field_name, value in data.items():
            if field_name in self.entries:
                entry = self.entries[field_name]
                if isinstance(entry, ctk.CTkComboBox):
                    entry.set(str(value) if value else "")
                else:
                    entry.delete(0, "end")
                    entry.insert(0, str(value) if value else "")


class FonksiyonTestleriTab(ctk.CTkFrame):
    """Fonksiyon testleri için özel tablo."""
    
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.rows = []
        self.create_widgets()
    
    def create_widgets(self):
        # Üst butonlar
        btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        btn_frame.pack(fill="x", padx=10, pady=5)
        
        ctk.CTkButton(btn_frame, text="+ Satır Ekle", command=self.add_row, width=120).pack(side="left", padx=5)
        ctk.CTkButton(btn_frame, text="- Son Satırı Sil", command=self.remove_row, width=120).pack(side="left", padx=5)
        
        # Başlık
        self.headers = ["No", "Linye Adı", "Eğri", "Kutup", "In(A)", "Icu", "Faz", "N", "PE", "Ib", "RCD mA", "RCD ms", "Sonuç"]
        
        # Tablo alanı
        self.scroll = ScrollableFrame(self)
        self.scroll.pack(fill="both", expand=True, padx=10, pady=5)
        
        # Başlık satırı
        header_frame = ctk.CTkFrame(self.scroll, fg_color="#1f538d")
        header_frame.pack(fill="x", pady=(0, 5))
        
        widths = [40, 150, 50, 50, 60, 50, 50, 50, 50, 60, 60, 60, 70]
        for i, (header, width) in enumerate(zip(self.headers, widths)):
            lbl = ctk.CTkLabel(header_frame, text=header, width=width, font=ctk.CTkFont(size=11, weight="bold"))
            lbl.pack(side="left", padx=1)
        
        # İlk 5 satırı ekle
        for _ in range(5):
            self.add_row()
    
    def add_row(self):
        """Yeni satır ekle."""
        row_num = len(self.rows) + 1
        row_frame = ctk.CTkFrame(self.scroll, fg_color="#2b2b2b")
        row_frame.pack(fill="x", pady=1)
        
        entries = {}
        
        # No
        lbl = ctk.CTkLabel(row_frame, text=str(row_num), width=40)
        lbl.pack(side="left", padx=1)
        
        # Linye Adı
        e = ctk.CTkEntry(row_frame, width=150, font=ctk.CTkFont(size=11))
        e.pack(side="left", padx=1)
        entries['Linye Adi'] = e
        
        # Eğri
        e = ctk.CTkComboBox(row_frame, values=["B", "C", "D", "K", "Z"], width=50, font=ctk.CTkFont(size=11))
        e.set("C")
        e.pack(side="left", padx=1)
        entries['Acma Egrisi'] = e
        
        # Kutup
        e = ctk.CTkComboBox(row_frame, values=["1", "2", "3", "4"], width=50, font=ctk.CTkFont(size=11))
        e.set("1")
        e.pack(side="left", padx=1)
        entries['Kutup Sayisi'] = e
        
        # In(A)
        e = ctk.CTkComboBox(row_frame, values=["6", "10", "16", "20", "25", "32", "40", "50", "63", "80", "100"], width=60, font=ctk.CTkFont(size=11))
        e.pack(side="left", padx=1)
        entries['In (A)'] = e
        
        # Icu
        e = ctk.CTkComboBox(row_frame, values=["4.5", "6", "10", "15", "25", "36"], width=50, font=ctk.CTkFont(size=11))
        e.pack(side="left", padx=1)
        entries['Icu (kA)'] = e
        
        # Faz kesiti
        e = ctk.CTkComboBox(row_frame, values=["1.5", "2.5", "4", "6", "10", "16", "25"], width=50, font=ctk.CTkFont(size=11))
        e.pack(side="left", padx=1)
        entries['Faz Kesiti (mm2)'] = e
        
        # N kesiti
        e = ctk.CTkComboBox(row_frame, values=["1.5", "2.5", "4", "6", "10", "16", "25"], width=50, font=ctk.CTkFont(size=11))
        e.pack(side="left", padx=1)
        entries['N Kesiti (mm2)'] = e
        
        # PE kesiti
        e = ctk.CTkComboBox(row_frame, values=["1.5", "2.5", "4", "6", "10", "16", "25"], width=50, font=ctk.CTkFont(size=11))
        e.pack(side="left", padx=1)
        entries['PE Kesiti (mm2)'] = e
        
        # Ib
        e = ctk.CTkEntry(row_frame, width=60, font=ctk.CTkFont(size=11))
        e.pack(side="left", padx=1)
        entries['Ib (A)'] = e
        
        # RCD mA
        e = ctk.CTkComboBox(row_frame, values=["", "30", "100", "300", "500"], width=60, font=ctk.CTkFont(size=11))
        e.pack(side="left", padx=1)
        entries['RCD mA'] = e
        
        # RCD ms
        e = ctk.CTkEntry(row_frame, width=60, font=ctk.CTkFont(size=11))
        e.pack(side="left", padx=1)
        entries['RCD ms'] = e
        
        # Sonuç
        e = ctk.CTkComboBox(row_frame, values=["Uygun", "Uygun Değil"], width=70, font=ctk.CTkFont(size=11))
        e.set("Uygun")
        e.pack(side="left", padx=1)
        entries['Sonuc'] = e
        
        self.rows.append({'frame': row_frame, 'entries': entries})
    
    def remove_row(self):
        """Son satırı sil."""
        if self.rows:
            row = self.rows.pop()
            row['frame'].destroy()
    
    def get_data(self) -> List[Dict[str, Any]]:
        """Tüm satır verilerini al."""
        data = []
        for row in self.rows:
            row_data = {}
            has_data = False
            for field, entry in row['entries'].items():
                if isinstance(entry, ctk.CTkComboBox):
                    val = entry.get()
                else:
                    val = entry.get()
                if val:
                    has_data = True
                row_data[field] = val
            if has_data:
                data.append(row_data)
        return data


class ElektrikRaporApp(ctk.CTk):
    """Ana uygulama penceresi."""
    
    def __init__(self):
        super().__init__()
        
        self.title("Elektrik Tesisatı Rapor Sistemi")
        self.geometry("1400x900")
        self.minsize(1200, 700)
        
        # Ana düzen
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        
        self.create_header()
        self.create_main_content()
        self.create_footer()
    
    def create_header(self):
        """Üst başlık alanı."""
        header = ctk.CTkFrame(self, height=60, fg_color="#1f538d")
        header.grid(row=0, column=0, sticky="ew", padx=0, pady=0)
        header.grid_propagate(False)
        
        title = ctk.CTkLabel(
            header, 
            text="⚡ Elektrik Tesisatı Gözle Kontrol ve Fonksiyon Testleri Rapor Sistemi",
            font=ctk.CTkFont(size=20, weight="bold"),
            text_color="white"
        )
        title.pack(side="left", padx=20, pady=15)
    
    def create_main_content(self):
        """Ana içerik alanı - sekmeler."""
        self.tabview = ctk.CTkTabview(self)
        self.tabview.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        
        # Sekmeler
        self.tab_firma = self.tabview.add("Firma Bilgileri")
        self.tab_pano = self.tabview.add("Ana Dağıtım Pano")
        self.tab_kontrol = self.tabview.add("Gözle Kontrol")
        self.tab_testler = self.tabview.add("Fonksiyon Testleri")
        self.tab_termal = self.tabview.add("Termal Görüntüler")
        
        self.create_firma_tab()
        self.create_pano_tab()
        self.create_kontrol_tab()
        self.create_testler_tab()
        self.create_termal_tab()
    
    def create_firma_tab(self):
        """Firma bilgileri sekmesi."""
        fields = [
            ("Firma Adi", "text", ""),
            ("Tesis Adı / Adresi", "text", ""),
            ("Kontrol Tarihi", "date", datetime.now().strftime("%d.%m.%Y")),
            ("Rapor No", "text", ""),
            ("Kontrol Eden", "text", ""),
            ("Kontrol Eden Belge No", "text", ""),
            ("SGK Sicil", "text", ""),
            ("Kontrol Baslangic", "text", ""),
            ("Kontrol Bitis", "text", ""),
            ("Sonraki Kontrol", "date", ""),
        ]
        self.firma_tab = DataEntryTab(self.tab_firma, fields)
        self.firma_tab.pack(fill="both", expand=True)
    
    def create_pano_tab(self):
        """Ana dağıtım pano sekmesi."""
        fields = [
            ("Enerji Saglayan Kurulus", "text", "TEDAŞ"),
            ("Kontrol Nedeni", "dropdown", ["Periyodik Kontrol", "İlk Kontrol"]),
            ("Topraklayici Tipi", "dropdown", ["Ring", "Yüzeysel", "Temel", "Derin", "Belirlenemedi"]),
            ("Yapi Cinsi", "dropdown", ["Ev", "Ticari", "Endüstri", "Diğer"]),
            ("Temel Topraklama Direnci (Ohm)", "number", ""),
            ("Ilave Topraklama Elektrotu Detaylari", "text", ""),
            ("Sistem Topraklama Iletkeni Kesiti (mm2)", "number", ""),
            ("Ana Espotansiyel Iletkeni Kesiti (mm2)", "number", ""),
            ("Dis Cevrim Empedansi Z_E (Ohm)", "number", ""),
            ("Ana Kesici Tipi", "dropdown", ["B", "C", "D"]),
            ("Ana Kesici Nominal Akimi", "text", ""),
            ("Ana RCD Tipi", "dropdown", ["KAKR", "TOROİD"]),
            ("Ana RCD Dayanim Akimi (mA)", "dropdown", ["30", "100", "300", "500"]),
            ("Ana RCD Test Akimi (mA)", "number", ""),
            ("Ana RCD Acma Suresi (ms)", "number", ""),
            ("Pano Adi (PANO_adi1)", "text", ""),
            ("Faz-Toprak Cevrim Empedansi Z_x (Ohm)", "number", ""),
            ("Faz-Notr Cevrim Empedansi Z_ln (Ohm)", "number", ""),
            ("Gerilim F-F (V)", "number", ""),
            ("Gerilim L-N (V)", "number", ""),
            ("Gerilim N-PE (V)", "number", ""),
            ("Parafudr Tipi", "dropdown", ["Tip 1", "Tip 2", "Tip 3", "Tip 1+2"]),
            ("Parafudr Imax (kA)", "number", ""),
        ]
        self.pano_tab = DataEntryTab(self.tab_pano, fields)
        self.pano_tab.pack(fill="both", expand=True)
    
    def create_kontrol_tab(self):
        """Gözle kontrol sekmesi."""
        fields = [
            ("Pano Adi", "text", ""),
            # PANO VE DİĞER DONANIMLARA GİRİŞİN UYGUNLUĞU
            ("Kablo Sebeke Tarafi", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_01
            ("Pano Sabitlenmesi", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_02
            ("Elektrik Panosu Etrafinda Yabanci Malzemeler", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_03
            ("Kablo Donanim Tarafi", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_04
            ("Dis Darbelere Karsi Koruma Onlemi", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_05
            ("Zemin Izolasyonu", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_06
            # TOPRAKLANMIŞ POTANSİYEL DENGELEME
            ("Topraklama Iletkeni", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_07
            ("Ek Potansiyel Dengeleme Iletkeni", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_08
            ("Ana Potansiyel Dengeleme Iletkeni", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_09
            ("Pano Kapak Baglantisi Kontrolu 6 mm2", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_10
            # KARŞILIKLI ZARARLI ETKİLERİN ÖNLENMESİ
            ("Elektriksel Olmayan Tesislere Yaklasma", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_11
            ("Guvenlik Devre Ayrilmasi", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_12
            ("Bant Ayrilmasi", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_13
            ("Pano Ic Kapak", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_14
            # TANIMLAMA
            ("Semalar Talimatlar", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_15
            ("Tehlike Isaretleri", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_16
            ("Koruma Cihaz ve Terminal Etiket", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_17
            # KABLO VE İLETKENLER
            ("Kablo Yollari", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_18
            ("Tesisat Yontemi", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_19
            ("Kablo Renk Kodlari", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_20
            ("Yangin Engeli", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_21
            # TERMAL KAMERA
            ("Kontak Gevsekligi Isinmasi", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_22
            ("Asiri Yuk Isinmasi", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_23
            ("Fotograf Tarihi", "text", ""),  # GK_24
            ("Fotograf No", "text", ""),  # GK_25
            # GENEL DEĞERLENDİRMELER
            ("Yangin Sondurme", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_26
            ("Korozyon Kontrolu", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_27
            ("Ekipman Temizlik", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_28
            ("Acil Durum Aydinlatma", "dropdown", ["Uygun", "Uygun Değil", "Uygulanamaz"]),  # GK_29
        ]
        self.kontrol_tab = DataEntryTab(self.tab_kontrol, fields)
        self.kontrol_tab.pack(fill="both", expand=True)
    
    def create_testler_tab(self):
        """Fonksiyon testleri sekmesi."""
        self.testler_tab = FonksiyonTestleriTab(self.tab_testler)
        self.testler_tab.pack(fill="both", expand=True)
    
    def create_termal_tab(self):
        """Termal görüntüler sekmesi."""
        frame = ctk.CTkFrame(self.tab_termal)
        frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Açıklama
        lbl = ctk.CTkLabel(
            frame, 
            text="Fluke termal kamera dosyalarını (.docx) aşağıya sürükleyip bırakın:",
            font=ctk.CTkFont(size=14)
        )
        lbl.pack(pady=(20, 10))
        
        # Sürükle-bırak alanı
        self.drop_zone = DragDropFrame(
            frame, 
            file_types=['.docx'],
            height=200
        )
        self.drop_zone.pack(fill="x", padx=50, pady=20)
        
        # Temizle butonu
        ctk.CTkButton(
            frame, 
            text="Dosyaları Temizle",
            command=self.drop_zone.clear,
            width=150
        ).pack(pady=10)
    
    def create_footer(self):
        """Alt butonlar alanı."""
        footer = ctk.CTkFrame(self, height=70, fg_color="#2b2b2b")
        footer.grid(row=2, column=0, sticky="ew", padx=0, pady=0)
        footer.grid_propagate(False)
        
        # Sol butonlar
        left_frame = ctk.CTkFrame(footer, fg_color="transparent")
        left_frame.pack(side="left", padx=20, pady=15)
        
        ctk.CTkButton(
            left_frame, 
            text="💾 Projeyi Kaydet",
            command=self.save_project,
            width=140
        ).pack(side="left", padx=5)
        
        ctk.CTkButton(
            left_frame, 
            text="📂 Proje Aç",
            command=self.load_project,
            width=140
        ).pack(side="left", padx=5)
        
        # Sağ butonlar
        right_frame = ctk.CTkFrame(footer, fg_color="transparent")
        right_frame.pack(side="right", padx=20, pady=15)
        
        ctk.CTkButton(
            right_frame, 
            text="📋 Rapor Oluştur",
            command=self.generate_report,
            width=180,
            height=40,
            font=ctk.CTkFont(size=14, weight="bold"),
            fg_color="#2e7d32",
            hover_color="#1b5e20"
        ).pack(side="right", padx=5)
    
    def get_all_data(self) -> Dict[str, Any]:
        """Tüm form verilerini topla."""
        return {
            'firma_bilgileri': self.firma_tab.get_data(),
            'ana_dagitim_pano': self.pano_tab.get_data(),
            'gozle_kontrol': {'kontroller': self.kontrol_tab.get_data()},
            'fonksiyon_testleri': self.testler_tab.get_data(),
            'termal_goruntuler': [{'fluke_dosya': f} for f in self.drop_zone.dropped_files]
        }
    
    def save_project(self):
        """Projeyi JSON olarak kaydet."""
        file_path = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON dosyası", "*.json")]
        )
        if file_path:
            data = self.get_all_data()
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            messagebox.showinfo("Başarılı", f"Proje kaydedildi:\n{file_path}")
    
    def load_project(self):
        """JSON projesini yükle."""
        file_path = filedialog.askopenfilename(
            filetypes=[("JSON dosyası", "*.json")]
        )
        if file_path:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Verileri formlara yükle
            if 'firma_bilgileri' in data:
                self.firma_tab.set_data(data['firma_bilgileri'])
            if 'ana_dagitim_pano' in data:
                self.pano_tab.set_data(data['ana_dagitim_pano'])
            if 'gozle_kontrol' in data and 'kontroller' in data['gozle_kontrol']:
                self.kontrol_tab.set_data(data['gozle_kontrol']['kontroller'])
            
            messagebox.showinfo("Başarılı", "Proje yüklendi!")
    
    def generate_report(self):
        """Rapor oluştur."""
        try:
            # Verileri topla
            data = self.get_all_data()
            
            # Çıktı dosyası seç
            output_path = filedialog.asksaveasfilename(
                defaultextension=".docx",
                filetypes=[("Word Belgesi", "*.docx")],
                initialfile=f"Rapor_{datetime.now().strftime('%Y%m%d_%H%M%S')}.docx"
            )
            
            if not output_path:
                return
            
            # Geçici Excel oluştur
            import tempfile
            temp_excel = tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False)
            temp_excel.close()
            
            # Verileri Excel'e yaz
            self.data_to_excel(data, temp_excel.name)
            
            # Rapor oluştur
            from report_generator import ReportGenerator
            template_path = r"c:\Users\cmshe\OneDrive\Masaüstü\BUILDV\Elektrik Tesisatı Gözle Kontrol ve Fonksyion Testleri Periyodik Kontrol Raporu.docx"
            
            generator = ReportGenerator(template_path)
            generator.generate(temp_excel.name, output_path)
            
            # Geçici dosyayı sil
            os.unlink(temp_excel.name)
            
            messagebox.showinfo("Başarılı", f"Rapor oluşturuldu:\n{output_path}")
            
            # Raporu aç
            os.startfile(output_path)
            
        except Exception as e:
            messagebox.showerror("Hata", f"Rapor oluşturulurken hata:\n{str(e)}")
    
    def data_to_excel(self, data: Dict[str, Any], output_path: str):
        """GUI verilerini Excel formatına dönüştür (ExcelReader uyumlu dikey format)."""
        from openpyxl import Workbook
        
        wb = Workbook()
        
        # FirmaBilgileri - Dikey format (A: key, B: value)
        ws_firma = wb.active
        ws_firma.title = "FirmaBilgileri"
        ws_firma.cell(row=1, column=1, value="Alan")
        ws_firma.cell(row=1, column=2, value="Değer")
        if 'firma_bilgileri' in data:
            for i, (key, value) in enumerate(data['firma_bilgileri'].items(), 2):
                ws_firma.cell(row=i, column=1, value=key)
                ws_firma.cell(row=i, column=2, value=value)
        
        # AnaDagitimPano - Dikey format
        ws_pano = wb.create_sheet("AnaDagitimPano")
        ws_pano.cell(row=1, column=1, value="Alan")
        ws_pano.cell(row=1, column=2, value="Değer")
        if 'ana_dagitim_pano' in data:
            for i, (key, value) in enumerate(data['ana_dagitim_pano'].items(), 2):
                ws_pano.cell(row=i, column=1, value=key)
                ws_pano.cell(row=i, column=2, value=value)
        
        # GozleKontrol - Dikey format (A: key, B: value, C: kusur)
        ws_kontrol = wb.create_sheet("GozleKontrol")
        ws_kontrol.cell(row=1, column=1, value="Kontrol Maddesi")
        ws_kontrol.cell(row=1, column=2, value="Değerlendirme")
        ws_kontrol.cell(row=1, column=3, value="Kusur Derecesi")
        if 'gozle_kontrol' in data and 'kontroller' in data['gozle_kontrol']:
            kontroller = data['gozle_kontrol']['kontroller']
            for i, (key, value) in enumerate(kontroller.items(), 2):
                ws_kontrol.cell(row=i, column=1, value=key)
                ws_kontrol.cell(row=i, column=2, value=value)
        
        # FonksiyonTestleri - Yatay format (başlık satırı + veri satırları)
        ws_test = wb.create_sheet("FonksiyonTestleri")
        if 'fonksiyon_testleri' in data and data['fonksiyon_testleri']:
            headers = list(data['fonksiyon_testleri'][0].keys())
            for i, h in enumerate(headers, 1):
                ws_test.cell(row=1, column=i, value=h)
            
            for row_idx, row_data in enumerate(data['fonksiyon_testleri'], 2):
                for col_idx, h in enumerate(headers, 1):
                    ws_test.cell(row=row_idx, column=col_idx, value=row_data.get(h, ''))
        
        # TermalGoruntuler - Dikey format
        ws_termal = wb.create_sheet("TermalGoruntuler")
        ws_termal.cell(row=1, column=1, value="Pano Adı")
        ws_termal.cell(row=1, column=2, value="fluke_dosya")
        if 'termal_goruntuler' in data:
            for i, termal in enumerate(data['termal_goruntuler'], 2):
                ws_termal.cell(row=i, column=1, value="Ana Pano")
                ws_termal.cell(row=i, column=2, value=termal.get('fluke_dosya', ''))
        
        wb.save(output_path)


def main():
    """Ana fonksiyon."""
    app = ElektrikRaporApp()
    app.mainloop()


if __name__ == "__main__":
    main()
