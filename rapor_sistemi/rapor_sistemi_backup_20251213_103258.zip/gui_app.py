"""
Elektrik Tesisatı Rapor Oluşturma GUI Uygulaması
Excel verilerinden DOCX raporu oluşturur.
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from typing import Optional
import os
import threading
import sys

# Modülleri import et
from report_generator import ReportGenerator


class RaporUygulamasi:
    """Ana GUI uygulaması."""
    
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Elektrik Tesisatı Rapor Oluşturucu")
        self.root.geometry("800x600")
        self.root.minsize(700, 500)
        
        # Varsayılan şablon yolu
        self.default_template = r"c:\Users\cmshe\OneDrive\Masaüstü\BUILDV\Elektrik Tesisatı Gözle Kontrol ve Fonksyion Testleri Periyodik Kontrol Raporu.docx"
        
        # Değişkenler
        self.excel_path = tk.StringVar()
        self.template_path = tk.StringVar(value=self.default_template)
        self.output_path = tk.StringVar()
        
        # Tema ayarla
        self.setup_style()
        
        # Arayüzü oluştur
        self.create_widgets()
        
    def setup_style(self):
        """Tema ve stil ayarları."""
        style = ttk.Style()
        style.theme_use('clam')
        
        # Özel stiller
        style.configure('Title.TLabel', font=('Segoe UI', 14, 'bold'))
        style.configure('Header.TLabel', font=('Segoe UI', 10, 'bold'))
        style.configure('Status.TLabel', font=('Segoe UI', 9))
        style.configure('Generate.TButton', font=('Segoe UI', 11, 'bold'))
        
    def create_widgets(self):
        """Arayüz bileşenlerini oluşturur."""
        # Ana çerçeve
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Başlık
        title_label = ttk.Label(
            main_frame, 
            text="⚡ Elektrik Tesisatı Periyodik Kontrol Raporu Oluşturucu",
            style='Title.TLabel'
        )
        title_label.pack(pady=(0, 20))
        
        # === Dosya Seçici Bölümü ===
        file_frame = ttk.LabelFrame(main_frame, text="Dosya Seçimi", padding="10")
        file_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Excel dosyası
        self.create_file_row(
            file_frame, 
            "Excel Veri Dosyası:", 
            self.excel_path, 
            self.select_excel,
            row=0
        )
        
        # Şablon dosyası
        self.create_file_row(
            file_frame, 
            "Rapor Şablonu (DOCX):", 
            self.template_path, 
            self.select_template,
            row=1
        )
        
        # Çıktı dosyası
        self.create_file_row(
            file_frame, 
            "Çıktı Dosyası:", 
            self.output_path, 
            self.select_output,
            row=2,
            is_save=True
        )
        
        # === Rapor Oluştur Butonu ===
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=15)
        
        self.generate_btn = ttk.Button(
            button_frame,
            text="📄 RAPOR OLUŞTUR",
            style='Generate.TButton',
            command=self.generate_report
        )
        self.generate_btn.pack(expand=True)
        
        # === İlerleme Çubuğu ===
        self.progress = ttk.Progressbar(
            main_frame, 
            mode='indeterminate',
            length=300
        )
        self.progress.pack(pady=(0, 10))
        
        # === Durum Etiketi ===
        self.status_label = ttk.Label(
            main_frame, 
            text="Hazır",
            style='Status.TLabel'
        )
        self.status_label.pack()
        
        # === Log Alanı ===
        log_frame = ttk.LabelFrame(main_frame, text="İşlem Günlüğü", padding="5")
        log_frame.pack(fill=tk.BOTH, expand=True, pady=(10, 0))
        
        self.log_text = scrolledtext.ScrolledText(
            log_frame, 
            height=10, 
            font=('Consolas', 9),
            state='disabled'
        )
        self.log_text.pack(fill=tk.BOTH, expand=True)
        
    def create_file_row(self, parent, label_text, variable, command, row, is_save=False):
        """Dosya seçici satırı oluşturur."""
        ttk.Label(parent, text=label_text).grid(row=row, column=0, sticky='w', pady=5)
        
        entry = ttk.Entry(parent, textvariable=variable, width=60)
        entry.grid(row=row, column=1, padx=5, pady=5, sticky='ew')
        
        btn_text = "Kaydet..." if is_save else "Gözat..."
        btn = ttk.Button(parent, text=btn_text, command=command, width=10)
        btn.grid(row=row, column=2, pady=5)
        
        parent.columnconfigure(1, weight=1)
        
    def select_excel(self):
        """Excel dosyası seçer."""
        filepath = filedialog.askopenfilename(
            title="Excel Veri Dosyası Seçin",
            filetypes=[
                ("Excel Dosyaları", "*.xlsx *.xls"),
                ("Tüm Dosyalar", "*.*")
            ]
        )
        if filepath:
            self.excel_path.set(filepath)
            self.log(f"Excel dosyası seçildi: {filepath}")
            
            # Otomatik çıktı adı öner
            if not self.output_path.get():
                base_name = os.path.splitext(os.path.basename(filepath))[0]
                output_dir = os.path.dirname(filepath)
                suggested = os.path.join(output_dir, f"{base_name}_Rapor.docx")
                self.output_path.set(suggested)
                
    def select_template(self):
        """Şablon dosyası seçer."""
        filepath = filedialog.askopenfilename(
            title="Rapor Şablonu Seçin",
            filetypes=[
                ("Word Dosyaları", "*.docx"),
                ("Tüm Dosyalar", "*.*")
            ],
            initialdir=os.path.dirname(self.default_template)
        )
        if filepath:
            self.template_path.set(filepath)
            self.log(f"Şablon seçildi: {filepath}")
            
    def select_output(self):
        """Çıktı dosyası seçer."""
        filepath = filedialog.asksaveasfilename(
            title="Raporu Kaydet",
            defaultextension=".docx",
            filetypes=[
                ("Word Dosyaları", "*.docx"),
                ("Tüm Dosyalar", "*.*")
            ]
        )
        if filepath:
            self.output_path.set(filepath)
            self.log(f"Çıktı konumu: {filepath}")
            
    def log(self, message: str):
        """Log mesajı ekler."""
        self.log_text.config(state='normal')
        self.log_text.insert(tk.END, f"• {message}\n")
        self.log_text.see(tk.END)
        self.log_text.config(state='disabled')
        
    def set_status(self, message: str):
        """Durum mesajını günceller."""
        self.status_label.config(text=message)
        self.root.update_idletasks()
        
    def generate_report(self):
        """Rapor oluşturma işlemini başlatır."""
        # Girdi doğrulama
        if not self.excel_path.get():
            messagebox.showerror("Hata", "Lütfen Excel veri dosyasını seçin!")
            return
            
        if not self.template_path.get():
            messagebox.showerror("Hata", "Lütfen rapor şablonunu seçin!")
            return
            
        if not self.output_path.get():
            messagebox.showerror("Hata", "Lütfen çıktı dosyası konumunu seçin!")
            return
            
        if not os.path.exists(self.excel_path.get()):
            messagebox.showerror("Hata", "Excel dosyası bulunamadı!")
            return
            
        if not os.path.exists(self.template_path.get()):
            messagebox.showerror("Hata", "Şablon dosyası bulunamadı!")
            return
        
        # Arayüzü devre dışı bırak
        self.generate_btn.config(state='disabled')
        self.progress.start(10)
        self.set_status("Rapor oluşturuluyor...")
        
        # Arka planda çalıştır
        thread = threading.Thread(target=self._generate_report_thread)
        thread.daemon = True
        thread.start()
        
    def _generate_report_thread(self):
        """Rapor oluşturma thread'i."""
        try:
            self.log("Rapor oluşturuluyor...")
            self.log(f"  Excel: {self.excel_path.get()}")
            self.log(f"  Şablon: {self.template_path.get()}")
            self.log(f"  Çıktı: {self.output_path.get()}")
            
            # Rapor oluştur
            generator = ReportGenerator(self.template_path.get())
            result = generator.generate(
                self.excel_path.get(),
                self.output_path.get()
            )
            
            # Başarılı
            self.root.after(0, self._on_success, result)
            
        except Exception as e:
            # Hata
            self.root.after(0, self._on_error, str(e))
            
    def _on_success(self, result_path: str):
        """Başarılı tamamlanma."""
        self.progress.stop()
        self.generate_btn.config(state='normal')
        self.set_status("Rapor başarıyla oluşturuldu!")
        self.log(f"✓ Rapor oluşturuldu: {result_path}")
        
        # Dosyayı aç mı?
        if messagebox.askyesno("Başarılı", 
                              f"Rapor başarıyla oluşturuldu!\n\n{result_path}\n\nDosyayı açmak ister misiniz?"):
            os.startfile(result_path)
            
    def _on_error(self, error_message: str):
        """Hata durumu."""
        self.progress.stop()
        self.generate_btn.config(state='normal')
        self.set_status("Hata oluştu!")
        self.log(f"✗ HATA: {error_message}")
        messagebox.showerror("Hata", f"Rapor oluşturulurken hata oluştu:\n\n{error_message}")


def main():
    """Ana fonksiyon."""
    root = tk.Tk()
    
    # Uygulama ikonu ayarla (varsa)
    try:
        root.iconbitmap('icon.ico')
    except:
        pass
    
    app = RaporUygulamasi(root)
    root.mainloop()


if __name__ == "__main__":
    main()
