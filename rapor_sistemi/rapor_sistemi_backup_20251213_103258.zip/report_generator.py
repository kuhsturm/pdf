"""
Rapor Üretici Modülü v2
Excel verilerini okuyarak DOCX raporu oluşturur.
Güncellemeler:
- Ana Dağıtım Pano desteği
- Otomatik kusur açıklaması
- Iz otomatik hesaplama
- Son 2 termal görsel
"""

from excel_reader import ExcelReader
from docx_writer import DocxWriter
from fluke_extractor import FlukeExtractor
from typing import Dict, Any, Optional
import os
import tempfile


class ReportGenerator:
    """Excel verilerinden DOCX raporu oluşturur."""
    
    def __init__(self, template_path: str):
        """
        Args:
            template_path: DOCX şablon dosyasının yolu
        """
        self.template_path = template_path
        self.temp_dir = None
        
    def generate(self, excel_path: str, output_path: str) -> str:
        """
        Rapor oluşturur.
        
        Args:
            excel_path: Veri içeren Excel dosyasının yolu
            output_path: Çıktı DOCX dosyasının yolu
            
        Returns:
            Oluşturulan raporun yolu
        """
        # Geçici klasör oluştur
        self.temp_dir = tempfile.mkdtemp(prefix="rapor_")
        
        try:
            # Excel verilerini oku
            print("Excel verileri okunuyor...")
            reader = ExcelReader(excel_path)
            data = reader.read_all()
            
            # DOCX yazıcıyı başlat
            print("Sablon yukleniyor...")
            writer = DocxWriter(self.template_path)
            writer.load_template()
            
            # Firma bilgilerini doldur
            if data.get('firma_bilgileri'):
                print("Firma bilgileri dolduruluyor...")
                writer.fill_firma_bilgileri(data['firma_bilgileri'])
            
            # Ana Dağıtım Pano bilgilerini doldur
            if data.get('ana_dagitim_pano'):
                print("Ana Dagitim Pano bilgileri dolduruluyor...")
                # Pano adını gözle kontrol verilerinden al
                pano_adi = None
                if data.get('gozle_kontrol'):
                    pano_adi = data['gozle_kontrol'].get('pano_adi')
                writer.fill_ana_dagitim_pano(data['ana_dagitim_pano'], pano_adi)
            
            # Cihaz bilgilerini doldur
            if data.get('cihaz_bilgileri'):
                print("Cihaz bilgileri dolduruluyor...")
                writer.fill_cihaz_bilgileri(data['cihaz_bilgileri'])
            
            # Gözle kontrol bölümünü doldur
            if data.get('gozle_kontrol'):
                print("Gozle kontrol verileri dolduruluyor...")
                writer.fill_gozle_kontrol(data['gozle_kontrol'])
            
            # Fonksiyon testlerini doldur (Iz otomatik hesaplanmış)
            if data.get('fonksiyon_testleri'):
                print(f"Fonksiyon testleri dolduruluyor ({len(data['fonksiyon_testleri'])} satir)...")
                # ana_dagitim_pano verisini placeholder değiştirme için geçir
                writer.fill_fonksiyon_testleri(data['fonksiyon_testleri'], data.get('ana_dagitim_pano'))
            
            # Termal görüntüleri işle (SON 2 GÖRSEL)
            if data.get('termal_goruntuler'):
                print("Termal goruntuler isleniyor...")
                all_images = []
                
                for termal in data['termal_goruntuler']:
                    fluke_path = termal.get('fluke_dosya')
                    
                    if fluke_path and os.path.exists(fluke_path):
                        try:
                            extractor = FlukeExtractor(fluke_path)
                            # only_last_two=True parametresi ile son 2 görseli al
                            result = extractor.extract_all(self.temp_dir)
                            all_images.extend(result.get('images', []))
                            print(f"  - {len(result.get('images', []))} gorsel cikarildi: {os.path.basename(fluke_path)}")
                        except Exception as e:
                            print(f"  ! Fluke dosyasi islenemedi: {fluke_path}, Hata: {e}")
                
                if all_images:
                    print(f"Toplam {len(all_images)} termal goruntu rapora ekleniyor...")
                    writer.add_thermal_images(all_images)
            
            # Kusur açıklamasını otomatik oluştur
            kusurlar = []
            if data.get('gozle_kontrol') and data['gozle_kontrol'].get('kusurlar'):
                kusurlar = data['gozle_kontrol']['kusurlar']
                print(f"Kusur aciklamasi olusturuluyor ({len(kusurlar)} kusur)...")
            
            # Sonuç bölümünü doldur
            sonuc_data = data.get('sonuc', {})
            writer.fill_sonuc(sonuc_data, kusurlar)
            
            # Raporu kaydet
            print(f"Rapor kaydediliyor: {output_path}")
            writer.save(output_path)
            
            print("Rapor basariyla olusturuldu!")
            return output_path
            
        finally:
            # Geçici dosyaları temizle
            self._cleanup_temp()
    
    def _cleanup_temp(self):
        """Geçici dosyaları temizler."""
        if self.temp_dir and os.path.exists(self.temp_dir):
            import shutil
            try:
                shutil.rmtree(self.temp_dir)
            except Exception:
                pass


def main():
    """Ana fonksiyon - komut satırı kullanımı için."""
    import sys
    
    if len(sys.argv) < 3:
        print("Kullanim: python report_generator.py <excel_dosyasi> <cikti_dosyasi>")
        print("Ornek: python report_generator.py veri.xlsx rapor.docx")
        sys.exit(1)
    
    excel_path = sys.argv[1]
    output_path = sys.argv[2]
    
    template_path = r"c:\Users\cmshe\OneDrive\Masaüstü\BUILDV\Elektrik Tesisatı Gözle Kontrol ve Fonksyion Testleri Periyodik Kontrol Raporu.docx"
    
    generator = ReportGenerator(template_path)
    
    try:
        result = generator.generate(excel_path, output_path)
        print(f"\n=== BASARILI ===")
        print(f"Rapor olusturuldu: {result}")
    except Exception as e:
        print(f"\n=== HATA ===")
        print(f"Rapor olusturulurken hata: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
